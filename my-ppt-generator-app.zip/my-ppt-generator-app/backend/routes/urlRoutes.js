// routes/urlRoutes.js
const express = require("express");
const router = express.Router();
const { fetchUrlContent } = require("../controllers/urlController");

router.post("/fetch-url", fetchUrlContent);

module.exports = router;
