// routes/pptRoutes.js
const express = require("express");
const router = express.Router();
const { generatePpt } = require("../controllers/pptController");

router.post("/generate-ppt", generatePpt);

module.exports = router;
