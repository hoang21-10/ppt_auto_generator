// controllers/pptController.js
const pptxgen = require("pptxgenjs");

const generatePpt = (req, res) => {
  const { title, content, fontSize, fontColor } = req.body;
  const ppt = new pptxgen();

  // Thêm slide đầu tiên với title
  ppt.addSlide({ title });

  // Thêm các slide khác với nội dung từ file
  content.split("\n").forEach((text) => {
    let slide = ppt.addSlide();
    slide.addText(text, { x: 0.5, y: 0.5, fontSize, color: fontColor });
  });

  // Tạo file PPTX tạm thời
  const filePath = `./temp/presentation.pptx`;
  
  // Ghi file PPTX vào đường dẫn tạm thời
  ppt.writeFile(filePath).then(() => {
    // Gửi file PPTX về client
    res.download(filePath, "presentation.pptx", (err) => {
      if (err) {
        console.error("Error downloading file:", err);
      }
      // Xóa file sau khi gửi
      fs.unlinkSync(filePath);
    });
  });
};

module.exports = { generatePpt };
