// controllers/fileController.js
const fs = require("fs");
const mammoth = require("mammoth");

const uploadFile = async (req, res) => {
  const filePath = req.file.path;
  let content = "";

  if (req.file.mimetype === "text/plain") {
    content = fs.readFileSync(filePath, "utf-8");
  } else if (req.file.mimetype === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
    const result = await mammoth.extractRawText({ path: filePath });
    content = result.value;
  } else {
    return res.status(400).json({ error: "Chỉ hỗ trợ TXT hoặc DOCX" });
  }

  fs.unlinkSync(filePath); // Xóa file sau khi xử lý
  res.json({ success: true, content });
};

module.exports = { uploadFile };
