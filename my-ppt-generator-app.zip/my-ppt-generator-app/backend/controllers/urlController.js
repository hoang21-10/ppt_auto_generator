// controllers/urlController.js
const axios = require("axios");
const cheerio = require("cheerio");

const fetchUrlContent = async (req, res) => {
  const { url } = req.body;
  try {
    const response = await axios.get(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    const $ = cheerio.load(response.data);
    const paragraphs = $("p").map((_, el) => $(el).text()).get();
    res.json({ success: true, content: paragraphs.join("\n") });
  } catch (error) {
    res.status(400).json({ error: "Không thể lấy nội dung từ URL" });
  }
};

module.exports = { fetchUrlContent };
