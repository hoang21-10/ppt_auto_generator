// controllers/authController.js
const admin = require("firebase-admin");

const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await admin.auth().getUserByEmail(email);
    res.json({ success: true, user });
  } catch (error) {
    res.status(400).json({ error: "Sai email hoặc mật khẩu" });
  }
};

const register = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await admin.auth().createUser({ email, password });
    res.json({ success: true, user });
  } catch (error) {
    res.status(400).json({ error: "Lỗi đăng ký" });
  }
};

module.exports = { login, register };
