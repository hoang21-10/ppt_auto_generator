const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const multer = require("multer");
const axios = require("axios");
const cheerio = require("cheerio");
const pptxgen = require("pptxgenjs");
const mammoth = require("mammoth");
const admin = require("firebase-admin");

// Cấu hình .env
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// 🔐 Firebase Admin SDK
const serviceAccount = require("./firebaseConfig.json");
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const auth = admin.auth();

// 📤 Upload: dùng bộ nhớ (không ghi file ra ổ đĩa)
const upload = multer({ storage: multer.memoryStorage() });

// 🔑 Đăng nhập
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await auth.getUserByEmail(email);
    const token = await admin.auth().createCustomToken(user.uid);
    res.json({ success: true, token });
  } catch (error) {
    res.status(401).json({ error: "Xác thực thất bại" });
  }
});

// 🆕 Đăng ký
app.post("/register", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await auth.createUser({ email, password });
    res.json({ success: true, uid: user.uid });
  } catch (error) {
    res.status(400).json({ error: "Tạo tài khoản thất bại" });
  }
});

// 📥 Tải file và trích xuất nội dung
app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: "Không có file upload" });

    let content = "";

    if (file.mimetype === "text/plain") {
      content = file.buffer.toString("utf-8");
    } else if (
      file.mimetype ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      const result = await mammoth.extractRawText({ buffer: file.buffer });
      content = result.value;
    } else {
      return res.status(400).json({ error: "Định dạng file không hỗ trợ" });
    }

    res.json({ success: true, content });
  } catch (error) {
    console.error("Lỗi xử lý file:", error);
    res.status(500).json({ error: "Lỗi xử lý file" });
  }
});

// 🌐 Trích xuất nội dung từ URL
app.post("/fetch-url", async (req, res) => {
  try {
    const { url } = req.body;
    const response = await axios.get(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    const $ = cheerio.load(response.data);

    let content = "";
    $("h1, h2, h3, p").each((_, el) => {
      content += $(el).text().trim() + "\n\n";
    });

    res.json({ success: true, content });
  } catch (error) {
    console.error("Lỗi fetch URL:", error);
    res.status(500).json({ error: "Không thể lấy nội dung" });
  }
});

// 📊 Tạo PowerPoint
app.post("/generate-ppt", async (req, res) => {
  try {
    const { title, content, fontSize = 24, fontColor = "363636" } = req.body;
    if (!title || !content) throw new Error("Thiếu tiêu đề hoặc nội dung");

    const ppt = new pptxgen();
    ppt.layout = "LAYOUT_WIDE";

    // Slide tiêu đề
    const titleSlide = ppt.addSlide();
    titleSlide.addText(title, {
      x: 0.5,
      y: 1.5,
      w: "90%",
      h: 2,
      fontSize: 32,
      bold: true,
      color: fontColor,
      align: "center",
    });

    // Nội dung - chia theo đoạn và dòng hợp lý
    const MAX_LINES_PER_SLIDE = 7;
    const MAX_CHARS_PER_LINE = 80;
    const paragraphs = content.split("\n\n").filter((p) => p.trim() !== "");
    let currentSlide = ppt.addSlide();
    let bulletPoints = [];
    let lineCount = 0;

    paragraphs.forEach((paragraph) => {
      const sentences = paragraph.split(/(?<=[.!?])\s+/); // tách câu

      sentences.forEach((sentence) => {
        const estimatedLines = Math.ceil(sentence.length / MAX_CHARS_PER_LINE);
        if (lineCount + estimatedLines > MAX_LINES_PER_SLIDE) {
          currentSlide.addText(bulletPoints, { x: 0.5, y: 1, w: "90%", h: "75%" });
          currentSlide = ppt.addSlide();
          bulletPoints = [];
          lineCount = 0;
        }

        bulletPoints.push({
          text: sentence.trim(),
          options: { fontSize, color: fontColor },
        });
        lineCount += estimatedLines;
      });
    });

    if (bulletPoints.length > 0) {
      currentSlide.addText(bulletPoints, { x: 0.5, y: 1, w: "90%", h: "75%" });
    }

    // Trả file về client
    const buffer = await ppt.write({ outputType: "nodebuffer" });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
    res.setHeader("Content-Disposition", "attachment; filename=presentation.pptx");
    res.end(buffer);
  } catch (error) {
    console.error("Lỗi tạo PPTX:", error);
    res.status(400).json({ error: error.message || "Lỗi tạo PPTX" });
  }
});

// 🚀 Khởi động server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Server đang chạy tại http://localhost:${PORT}`);
});
