# PowerPoint Generator - Frontend

## Cài đặt và Sử dụng

1. Clone dự án về máy tính của bạn:
    ```
    git clone <URL của dự án>
    ```

2. Cài đặt các thư viện cần thiết (nếu cần):
    ```
    npm install
    ```

3. Mở file `index.html` trong trình duyệt.

4. Các chức năng:
   - Đăng nhập và Đăng ký người dùng.
   - Upload file TXT/DOCX và tạo PowerPoint từ nội dung trong file.
   - Lấy nội dung từ URL và tạo PowerPoint từ nội dung.
   - Tạo PowerPoint với tiêu đề và nội dung tự nhập.

5. Đảm bảo backend của bạn đang chạy trên `http://localhost:5000` (hoặc thay đổi URL trong file `script.js` nếu cần).
