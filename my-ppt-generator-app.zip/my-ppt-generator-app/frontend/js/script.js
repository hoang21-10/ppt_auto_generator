// script.js

const apiUrl = "http://localhost:5000"; // Địa chỉ backend

// Đăng nhập
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  
  fetch(`${apiUrl}/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  })
  .then(response => response.json())
  .then(data => {
    alert("Đăng nhập thành công!");
  })
  .catch(error => {
    alert("Đăng nhập thất bại!");
  });
});

// Đăng ký
document.getElementById("registerForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const email = document.getElementById("regEmail").value;
  const password = document.getElementById("regPassword").value;
  
  fetch(`${apiUrl}/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  })
  .then(response => response.json())
  .then(data => {
    alert("Đăng ký thành công!");
  })
  .catch(error => {
    alert("Đăng ký thất bại!");
  });
});

// Tải file lên
function uploadFile() {
  const fileInput = document.getElementById("fileInput");
  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append("file", file);

  fetch(`${apiUrl}/upload`, {
    method: "POST",
    body: formData,
  })
  .then(response => response.json())
  .then(data => {
    alert("Tải lên thành công!");
  })
  .catch(error => {
    alert("Tải lên thất bại!");
  });
}

// Lấy nội dung từ URL
function fetchContentFromURL() {
  const url = document.getElementById("urlInput").value;

  fetch(`${apiUrl}/fetch-url`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ url }),
  })
  .then(response => response.json())
  .then(data => {
    document.getElementById("pptContent").value = data.content;
    alert("Lấy nội dung thành công!");
  })
  .catch(error => {
    alert("Lấy nội dung thất bại!");
  });
}

// Tạo PowerPoint
function generatePPT() {
  const title = document.getElementById("pptTitle").value;
  const content = document.getElementById("pptContent").value;
  
  fetch(`${apiUrl}/generate-ppt`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ title, content, fontSize: 18, fontColor: "000000" }),
  })
  .then(response => response.blob())
  .then(blob => {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "presentation.pptx";
    link.click();
    alert("Tạo PowerPoint thành công!");
  })
  .catch(error => {
    alert("Tạo PowerPoint thất bại!");
  });
}
